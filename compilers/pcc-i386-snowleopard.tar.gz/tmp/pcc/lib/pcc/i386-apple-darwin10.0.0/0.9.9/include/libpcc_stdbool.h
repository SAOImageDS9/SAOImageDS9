#ifndef _LIBPCC_STDBOOL_H_
#define _LIBPCC_STDBOOL_H_

#define __bool_true_false_are_defined	1

#ifndef __cplusplus

#define bool	_Bool
#define true	1
#define false	0

#endif

#endif
